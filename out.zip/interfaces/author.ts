type Author = {
  name: string
  picture: string
}

export default Author
